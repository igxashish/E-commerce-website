const wrapper = document.querySelector(".sliderWrapper");
const menuItems = document.querySelectorAll(".menuItem");


const products = [
  {
    id: 1,
    title: "Gucci",
    price: 539,
    colors: [
      {
        code: "black",
        img: "./img/gucci1.webp",
      },
      {
        code: "darkblue",
        img: "./img/gucci1.webp",
      },
    ],
  },
  {
    id: 2,
    title: "Gucci",
    price: 549,
    colors: [
      {
        code: "lightgray",
        img: "./img/gucci2.jpeg",
      },
      {
        code: "green",
        img: "./img/gucci2.jpeg",
      },
    ],
  },
  {
    id: 3,
    title: "Gucci",
    price: 699,
    colors: [
      {
        code: "lightgray",
        img: "./img/gucci3.jpeg",
      },
      {
        code: "green",
        img: "./img/gucci3.jpeg",
      },
    ],
  },
  {
    id: 4,
    title: "Gucci",
    price: 629,
    colors: [
      {
        code: "black",
        img: "./img/gucci4.jpg",
      },
      // {
      //   code: "lightgray",
      //   img: "./img/gucci4.jpg",

      // },
    ],
  },
  {
    id: 5,
    title: "Gucci",
    price: 719,
    colors: [
      {
        code: "gray",
        img: "./img/gucci5.avif",
      },
      {
        code: "black",
        img: "./img/gucci5.avif",
      },
    ],
  },
];

let choosenProduct = products[0];

const currentProductImg = document.querySelector(".productImg");
const currentProductTitle = document.querySelector(".productTitle");
const currentProductPrice = document.querySelector(".productPrice");
const currentProductColors = document.querySelectorAll(".color");
const currentProductSizes = document.querySelectorAll(".size");

menuItems.forEach((item, index) => {
  item.addEventListener("click", () => {
    //change the current slide
    wrapper.style.transform = `translateX(${-100 * index}vw)`;

    //change the choosen product
    choosenProduct = products[index];

    //change texts of currentProduct
    currentProductTitle.textContent = choosenProduct.title;
    currentProductPrice.textContent = "$" + choosenProduct.price;
    currentProductImg.src = choosenProduct.colors[0].img;

    //assing new colors
    currentProductColors.forEach((color, index) => {
      color.style.backgroundColor = choosenProduct.colors[index].code;
    });
  });
});

currentProductColors.forEach((color, index) => {
  color.addEventListener("click", () => {
    currentProductImg.src = choosenProduct.colors[index].img;
  });
});

currentProductSizes.forEach((size, index) => {
  size.addEventListener("click", () => {
    currentProductSizes.forEach((size) => {
      size.style.backgroundColor = "white";
      size.style.color = "black";
    });
    size.style.backgroundColor = "black";
    size.style.color = "white";
  });
});

const productButton = document.querySelector(".productButton");
const payment = document.querySelector(".payment");
const close = document.querySelector(".close");

productButton.addEventListener("click", () => {
  payment.style.display = "flex";
});

close.addEventListener("click", () => {
  payment.style.display = "none";
});

const linkButton  = document.querySelector(".limitedOffer");
linkButton.addEventListener("click", () => {
  window.open("https://www.google.com/maps/place/Civil+Lines,+Bareilly,+Uttar+Pradesh/@28.337693,79.4359685,14z/data=!3m1!4b1!4m6!3m5!1s0x39a000da1f058f65:0x23a3031c2956371e!8m2!3d28.3349422!4d79.4339003!16s%2Fm%2F0r3vsb8?entry=ttu");
});




// let bnm = alert("Welcome to Byenmore.com");